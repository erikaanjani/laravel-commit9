<?php

namespace App\Http\Controllers;

use App\Models\Groups;
use App\Models\Friends;
use Illuminate\Http\Request;

class GroupsController extends Controller
@@ -103,4 +103,32 @@ public function destroy($id)
        Groups::find($id)->delete();
        return redirect('/groups');
    }

    public function addmember($id)
    {
        $friend = Friends::where('groups_id', '=', 0)->get();
        $group = Groups::where('id', $id)->first();
        return view('groups.addmember', ['group' => $group, 'friend' => $friend]);
    }

    public function updateaddmember(Request $request, $id)
    {
        $friend = Friends::where('id', $request->friend_id)->first();
        Friends::find($friend->id)->update([
            'groups_id' => $id
        ]);

        return redirect('/groups/addmember/'. $id);
    }

    public function deleteaddmember(Request $request, $id)
    {

        Friends::find($id)->update([
            'groups_id' => 0
        ]);

        return redirect('/groups');
    }

}